# Synthetic release example

Bundled demo only; no scientific generalization claim.

## Artifacts

- dataset `94dd9ca1-7cae-4a5b-b152-2e0a7147fe33`; parents: none

- audit `6a83d25a-f6c0-4b38-b4b3-ad9ffa57e246`; parents: 94dd9ca1-7cae-4a5b-b152-2e0a7147fe33

  Findings: 1

- split `4ff25945-c0b2-4660-994d-e6518370f7b1`; parents: 94dd9ca1-7cae-4a5b-b152-2e0a7147fe33, 6a83d25a-f6c0-4b38-b4b3-ad9ffa57e246

- benchmark `4ccfb5a8-f767-4845-b6f3-8ac82f5fda3f`; parents: 94dd9ca1-7cae-4a5b-b152-2e0a7147fe33, 4ff25945-c0b2-4660-994d-e6518370f7b1

  Status: succeeded; metrics: {"validation": {"mae": 0.16984272938345746, "rmse": 0.19447236139612203, "r2": 0.6351353369931175, "group_mae": 0.16984272938345749, "group_rmse": 0.194472361396122, "group_mae_interval95": [0.11643473873705468, 0.20618190303162112], "rows": 12, "groups": 4, "interval_scope": "Percentile bootstrap of declared groups, conditional on this fixed test set/model; proxy groups do not prove experimental independence."}, "test": {"mae": 0.13337193095760883, "rmse": 0.15049367657183677, "r2": 0.8781666097194833, "group_mae": 0.13337193095760883, "group_rmse": 0.15049367657183674, "group_mae_interval95": [0.09369569933685482, 0.1822414084317178], "rows": 12, "groups": 4, "interval_scope": "Percentile bootstrap of declared groups, conditional on this fixed test set/model; proxy groups do not prove experimental independence."}}; error: None