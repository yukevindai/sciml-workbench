# Reproducible SciML Workbench report

All results are local task results; no official leaderboard admission is implied.
Dataset declarations may be unresolved; supplied declarations are assertions. Audit findings do not certify validity.
Failed runs are retained; software failure is not an experimental outcome.

## Replay
Install the workbench backend at version 0.1.0 using its pinned dependencies.
Run `python -m workbench.replay /path/to/report.zip /new/output-directory`.
This verifies every manifest digest and reruns audits, partitions and successful baselines.
Export verifies structure only; scientific replay has not run. Replay comparisons use rtol=1e-9, atol=1e-12.
Agent text and external side effects are not deterministically replayed. Hashes do not prove authorship.
It never reimports Failure Memory records. Each benchmark bundle also contains the upstream
task card, input, frozen partitions, prepared files, predictions and metrics.
Keep this archive private: it contains the uploaded data and evidence.
